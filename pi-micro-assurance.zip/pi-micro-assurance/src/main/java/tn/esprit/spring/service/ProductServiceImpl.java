package tn.esprit.spring.service;

import java.util.List;

import org.springframework.stereotype.Service;

import tn.esprit.spring.dao.entities.Product;
import tn.esprit.spring.dao.entities.User;

@Service
public class ProductServiceImpl  implements IProductService{

	@Override
	public List<Product> retrieveAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product addProduct(Product p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User updateProduct(Product u) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User retrieveProduct(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
