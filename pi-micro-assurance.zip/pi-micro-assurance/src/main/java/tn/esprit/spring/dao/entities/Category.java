package tn.esprit.spring.dao.entities;

public enum Category {
	
	life_insurance , agriculture_insurance

}
