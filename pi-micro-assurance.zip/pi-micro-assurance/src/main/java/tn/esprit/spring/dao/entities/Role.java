package tn.esprit.spring.dao.entities;

public enum Role {
	ADMIN,INSURER,INSURED,CUSTOMER

}
